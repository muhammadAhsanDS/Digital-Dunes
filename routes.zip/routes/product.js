const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// Define the storage for the uploaded images
const storage = multer.diskStorage({
    destination: './uploads',
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const extension = path.extname(file.originalname);
      cb(null, file.fieldname + '-' + uniqueSuffix + extension);
    }
  });
  
  // Create the multer instance
  const upload = multer({ storage });


  const productSchema = new mongoose.Schema({
    id:
    {
        type:String,
        default: uuidv4,
        required: true,
        unique: true
    },
    name: {
      type: String,
      required: true
    },
    description: {
      type: String,
      required: true
    },
    price: {
      type: Number,
      required: true
    },
    category: {
        type: String,
        required: true
      },
    image: {
      type: String,
      required: true
    },
    by:{
      type: String,
      required: true
    }},
    { collection: 'Product' }
);
  
  const Product = mongoose.model('Product', productSchema);  

  module.exports = function(app) {

  app.post('/upload/:productId', upload.single('image'), async (req, res) => {
    try {
      const id = req.params.productId;
      const image = req.file.path; // Path of the uploaded image file
      const imageName = path.basename(image);
      const updatedProduct = await Product.findOneAndUpdate(
        { id: id },
        { image:imageName },
        { new: true }
      );
  
      if (!updatedProduct) {
        return res.status(404).json({ message: 'Product not found' });
      }
  
      res.status(200).json({ message: 'Image updated successfully', product: updatedProduct });
    } catch (error) {
      console.error('Failed to update image', error);
      res.status(500).json({ message: 'Failed to update image' });
    }
  });
  

// Update a product
app.put('/products/:id', async (req, res) => {
    try {
      const id = req.params.id;
      const changed = req.body;
      console.log(req.body)
      const updatedProduct = await Product.findOneAndUpdate({ id }, changed, { new: true });
      console.log(updatedProduct)
      res.status(200).json(updatedProduct);
    } catch (error) {
      console.error(`Failed to update product ${req.params.productId}`, error);
      res.status(500).json({ message: `Failed to update product ${req.params.productId}` });
    }
  });
  
  // Delete a product
  app.delete('/products/:productId', async (req, res) => {
    try {
      const productId = req.params.productId;
      await Product.findOneAndDelete({ id:productId });
      res.status(204).send();
    } catch (error) {
      console.error(`Failed to delete product ${req.params.productId}`, error);
      res.status(500).json({ message: `Failed to delete product ${req.params.productId}` });
    }
  });
  
  // Get product by its name
  app.get('/products/:name', async (req, res) => {
    try {
      const name = req.params.name;
  
      const products = await Product.find({ name });
      res.status(200).json(products);
    } catch (error) {
      console.error(`Failed to fetch products from category ${req.params.categoryname}`, error);
      res.status(500).json({ message: `Failed to fetch products from category ${req.params.categoryname}` });
    }
  });

  // Get products by category
app.get('/products/category/:categoryname', async (req, res) => {
    try {
      const category = req.params.categoryname;
  
      const products = await Product.find({ category });
      res.status(200).json(products);
    } catch (error) {
      console.error(`Failed to fetch products from category ${req.params.categoryname}`, error);
      res.status(500).json({ message: `Failed to fetch products from category ${req.params.categoryname}` });
    }
  });

  // Get the products by username
  app.get('/products/username/:username', async (req, res) => {
    try {
      const username = req.params.username;
  
      const products = await Product.find({ by: username });
      res.status(200).json(products);
    } catch (error) {
      console.error(`Failed to fetch products uploaded by ${req.params.username}`, error);
      res.status(500).json({ message: `Failed to fetch products uploaded by ${req.params.username}` });
    }
  });  
  
    // Get all Products
    app.get('/all', async (req, res) => {
      try {
        const products = await Product.find();
        res.status(200).json(products);
        } catch (error) {
        console.error('Failed to fetch products', error);
        res.status(500).json({ message: 'Failed to fetch products' });
        }
    });
  

  }