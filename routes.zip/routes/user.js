const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
    username: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    phonenumber: {
      type: Number,
      required: true,
    }},
    { collection: 'User' }
  );
  
  const User = mongoose.model('User', userSchema);
  module.exports = function(app) {

    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));

  app.post('/signup', async (req, res) => {
    try {
      const { username, password, phonenumber } = req.body;
      
      const hashedPassword = await bcrypt.hash(password, 10);
  
      const newUser = new User({ username, password: hashedPassword,phonenumber });
      await newUser.save();
      res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
      console.error('Failed to create user', error);
      res.status(500).json({ message: 'Failed to create user' });
    }
  });
  
  app.post('/login', async (req, res) => {
    try {
      const { username, password } = req.body;
  
      // Find the user by username
      const user = await User.findOne({ username });
  
      // Check if the user exists
      if (!user) {
        return res.status(401).json({ message: 'Invalid username or password' });
      }
  
      // Compare the provided password with the hashed password
      const passwordMatch = await bcrypt.compare(password, user.password);
  
      // Check if the password matches
      if (!passwordMatch) {
        return res.status(401).json({ message: 'Invalid username or password' });
      }
  
      // Password is correct, authentication successful
      res.status(200).json({ message: 'Authentication successful' });
    } catch (error) {
      console.error('Failed to authenticate user', error);
      res.status(500).json({ message: 'Failed to authenticate user' });
    }
  });

}
  