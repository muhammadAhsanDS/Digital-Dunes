const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');

const contactSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  message: {
    type: String,
    required: true
  }},
  { collection: 'Contact' }
);

const Contact = mongoose.model('Contact', contactSchema);

module.exports = function(app) {

    app.post('/contact', async (req, res) => {
        try {
          const { name, email, message } = req.body;
          // Validate the data recieved
          if (!name || !email || !message) {
            return res.status(400).json({ message: 'Invalid request body' });
          }
      
          const contact = new Contact({ name, email, message });
          // Save the data in the database
          await contact.save();
      
          res.status(201).json({ message: 'Contact created successfully' });
        } catch (error) {
          console.error('Failed to create contact', error);
          res.status(500).json({ message: 'Failed to create contact' });
        }
      });
}
