const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');

const cartSchema = new mongoose.Schema({
    cartid:
    {
        type:String,
        default: uuidv4,
        required: true,
        unique: true
    },
    items: [
      {
        productId: {
          type: String,
          ref: 'Product',
          required: true
        },
        quantity: {
          type: Number,
          required: true
        }
      }
    ],
    total: {
      type: Number,
      required: true
    }},
    { collection: 'Order' }
    );
  
  const Cart = mongoose.model('Cart', cartSchema);

  module.exports = function(app) {

    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));

    app.post('/cart', async (req, res) => {
        try {
          const { items, total } = req.body;
      
          const cartid = uuidv4();
          
          console.log(items)
          // Validate the request body
          if ( !Array.isArray(items) || !total) {
            return res.status(400).json({ message: 'Invalid request body' });
          }
      
          // Create a new cart document
          const cart = new Cart({
            cartid,
            items,
            total
          });
      
          // Save the cart to the database
          await cart.save();
      
          res.status(201).json({ message: 'Cart created successfully' });
        } catch (error) {
          console.error('Failed to create cart', error);
          res.status(500).json({ message: 'Failed to create cart' });
        }
      });      


  

}
